import logo from "./BLK_LOGO.jpeg";  
import Bg_Image from "./ReatilImg.jpg";
import Nutz from "./Nutz.jpg";
// import NoImagePreview from "../../public/images/no-image-preview.png";

export const IMAGES = {
  logo,
  Nutz,
  Bg_Image,
  DummyImage: "/images/no-image-preview.png",
};
