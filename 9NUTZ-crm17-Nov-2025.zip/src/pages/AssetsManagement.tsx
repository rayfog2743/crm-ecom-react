import React from 'react'

const AssetsManagement = () => {
  return (
    <div>AssetsManagement</div>
  )
}

export default AssetsManagement