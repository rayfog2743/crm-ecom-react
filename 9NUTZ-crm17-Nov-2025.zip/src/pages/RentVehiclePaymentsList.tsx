import React from 'react'

const RentVehiclePaymentsList = () => {
  return (
    <div>RentVehiclePaymentsList</div>
  )
}

export default RentVehiclePaymentsList