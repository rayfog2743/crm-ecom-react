import React from 'react'

const GstCacheReport = () => {
  return (
    <div>GstCacheReport</div>
  )
}

export default GstCacheReport