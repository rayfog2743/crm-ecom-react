import React from 'react'

const CategoryManagement = () => {
  return (
    <div>CategoryManagement</div>
  )
}

export default CategoryManagement