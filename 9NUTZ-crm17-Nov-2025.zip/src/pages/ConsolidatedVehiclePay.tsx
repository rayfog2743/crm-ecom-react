import React from 'react'

const ConsolidatedVehiclePay = () => {
  return (
    <div>ConsolidatedVehiclePay</div>
  )
}

export default ConsolidatedVehiclePay