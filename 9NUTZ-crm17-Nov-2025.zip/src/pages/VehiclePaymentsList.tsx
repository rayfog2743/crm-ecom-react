import React from 'react'

const VehiclePaymentsList = () => {
  return (
    <div>VehiclePaymentsList</div>
  )
}

export default VehiclePaymentsList