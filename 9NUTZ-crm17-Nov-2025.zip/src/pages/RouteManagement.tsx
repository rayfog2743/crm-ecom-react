import React from 'react'

const RouteManagement = () => {
  return (
    <div>RouteManagement</div>
  )
}

export default RouteManagement